// class Employee {
//     private _name: string;
//     // private _name = "NA";

//     // Multiple constructor implementations are not allowed.
//     // constructor() {
//     //     this._name = "NA";
//     // }

//     // constructor(name?: string) {
//     //     this._name = name;
//     // }

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     // Never use Function Expression Syntax to create member functions, it will increase the memory usage
//     // getName = function () {
//     //     return this._name;
//     // }

//     // Never use Lambda to create member functions, it will increase the memory usage
//     // getName = () => {
//     //     return this._name;
//     // }

//     setName(value: string) {
//         this._name = value;
//     }
// }

// // var e1 = new Employee();
// var e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// // --------------------------------------------------------------- Strict Mode

// class Employee {
//     // private _name = "NA";

//     // private _name: string;

//     // constructor(name = "NA") {
//     //     this._name = name;
//     // }

//     private _name?: string;

//     getName() {
//         return this._name;
//     }

//     setName(value: string) {
//         this._name = value;
//     }
// }

// var e1 = new Employee();
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// // --------------------------------------------------------------- Properties

// class Employee {
//     private _name: string;
//     private _age: number;

//     constructor(name = "NA", age = 0) {
//         this._name = name;
//         this._age = age;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(value: string) {
//         this._name = value;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee();
// console.log(`Name: ${e1.Name}`);
// console.log(`Age: ${e1.Age}`);
// e1.Name = "Abhijeet";
// e1.Age = 38;
// console.log(`Name: ${e1.Name}`);
// console.log(`Age: ${e1.Age}`);

// --------------------------------------------------------------- Parameter Property/Parameter Members
// Parameter Property/Parameter Member let us create and initialize member variables in one place. 
// It is a shorthand for creating member variables.

// class Employee {
//     // constructor(private _name: string, private _age: number) { }
//     constructor(private _name = "NA", private _age = 0) { }

//     get Name() {
//         return this._name;
//     }

//     set Name(value: string) {
//         this._name = value;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee();
// console.log(`Name: ${e1.Name}`);
// console.log(`Age: ${e1.Age}`);
// e1.Name = "Abhijeet";
// e1.Age = 38;
// console.log(`Name: ${e1.Name}`);
// console.log(`Age: ${e1.Age}`);

// --------------------------------------------------------------- Static Members

// class BankAccount {
//     constructor(private _accName: string, private _bankName: string) { }

//     get BankName(): string {
//         return this._bankName;
//     }

//     set BankName(value: string) {
//         this._bankName = value;
//     }

//     get AccountHolderName(): string {
//         return this._accName;
//     }
// }

// var a1 = new BankAccount("Manish", "ICICI");
// console.log(a1);
// console.log(`Bank Name: ${a1.BankName}`);
// console.log(`Account Holder Name: ${a1.AccountHolderName}`);

// var a2 = new BankAccount("Abhijeet", "ICICI");
// console.log(a2);
// console.log(`Bank Name: ${a2.BankName}`);
// console.log(`Account Holder Name: ${a2.AccountHolderName}`);

// --------------------------------

// class BankAccount {
//     // private static _bankName: string;
//     private static _bankName = "HDFC";

//     constructor(private _accName: string) { }

//     get BankName(): string {
//         return BankAccount._bankName;
//     }

//     static set BankName(value: string) {
//         BankAccount._bankName = value;
//     }

//     get AccountHolderName(): string {
//         return this._accName;
//     }
// }

// // BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log(a1);
// console.log(`Bank Name: ${a1.BankName}`);
// console.log(`Account Holder Name: ${a1.AccountHolderName}`);

// var a2 = new BankAccount("Abhijeet");
// console.log(a2);
// console.log(`Bank Name: ${a2.BankName}`);
// console.log(`Account Holder Name: ${a2.AccountHolderName}`);

// --------------------------------------------------------------- 

class BankAccount {
    private static _bankName = "HDFC";

     // read-only property can be initialized only in the constructor 
    constructor(private readonly _accNumber: number, private _accName: string) { }

    get BankName(): string {
        return BankAccount._bankName;
    }

    static set BankName(value: string) {
        BankAccount._bankName = value;
    }

    get AccountNumber(): number {
        // this._accNumber = 100;          // Error: Cannot assign to '_accNumber' because it is a read-only property
        return this._accNumber;
    }

    get AccountHolderName(): string {
        return this._accName;
    }
}

var a1 = new BankAccount(1, "Manish");
console.log(`\nBank Name: ${a1.BankName}`);
console.log(`Account Number: ${a1.AccountNumber}`);
console.log(`Account Holder Name: ${a1.AccountHolderName}`);

var a2 = new BankAccount(2, "Abhijeet");
console.log(`\nBank Name: ${a2.BankName}`);
console.log(`Account Number: ${a2.AccountNumber}`);
console.log(`Account Holder Name: ${a2.AccountHolderName}`);