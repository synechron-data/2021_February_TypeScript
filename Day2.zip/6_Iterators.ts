// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }

//     [Symbol.iterator]() {
//         const self = this;
//         let i = 0;

//         return {
//             next: function () {
//                 let v, d = true;

//                 if (self._data[i] !== undefined) {
//                     v = self._data[i];
//                     d = false;
//                     i += 1;
//                 }

//                 return {
//                     value: v,
//                     done: d
//                 };
//             }
//         };
//     }
// }

// var numbersQ = new Queue<number>();

// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// for (const item of numbersQ) {
//     console.log(item);
// }

// --------------------------------------------------------------------- Generators

// A generator is a special type of function that during its execution it can be paused, 
// yield results back to the caller and resume later, at caller's convenience. 
// And this can happen as long as the generator has something to return, some value to yield back.

// function* idGenerator() {
//     var id = 0;
//     while (true) {
//         yield id++;
//     }
// }

// function* idGenerator() {
//     var id = 0;
//     while (id < 3) {
//         yield id++;
//     }
// }

// var genObj = idGenerator();
// console.log(genObj);

// console.log(genObj.next());
// console.log(genObj.next());
// console.log(genObj.next());
// console.log(genObj.next());

// for (const item of genObj) {
//     console.log(item);
// }

// ----------------------------------

// function* idGenerator() {
//     console.log("Execution Started....");
//     yield 1;
//     console.log("Execution Resumed - 1....");
//     yield 2;
//     console.log("Execution Resumed - 2....");
//     yield 3;
// }

// var genObj = idGenerator();

// console.log("Starting Iteration...");
// console.log(genObj.next());
// console.log("First Pause...");
// console.log(genObj.next());
// console.log("Second Pause...");
// console.log(genObj.next());
// console.log("Third Pause...");
// console.log(genObj.next());

// ---------------------------------------
// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }

//     *[Symbol.iterator]() {
//         for (let i = 0; i < this._data.length; i++) {
//             yield this._data[i];
//         }
//     }
// }

// var numbersQ = new Queue<number>();

// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// for (const item of numbersQ) {
//     console.log(item);
// }

// ---------------------------------------
class Queue<T> {
    private _data: T[] = [];

    push(d: T) {
        this._data.push(d);
    }

    pop(): T | undefined {
        return this._data.shift();
    }

    *[Symbol.iterator]() {
        yield* this._data;
    }
}

var numbersQ = new Queue<number>();

numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

for (const item of numbersQ) {
    console.log(item);
}