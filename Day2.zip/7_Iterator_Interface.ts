// class MyQueue<T> implements Iterable<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }

//     [Symbol.iterator](): Iterator<T> {
//         return new DataIterator(this._data);
//     }
// }

// class DataIterator<T> implements Iterator<T> {
//     constructor(private _data: T[], private _i = 0) { }

//     next(): IteratorResult<T> {
//         const self = this;
//         let v, d = true;

//         if (self._data[this._i] !== undefined) {
//             v = self._data[this._i];
//             d = false;
//             this._i += 1;
//         }

//         return {
//             value: v,
//             done: d
//         };
//     }
// }

// var numberQ = new MyQueue<number>();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// for (const item of numberQ) {
//     console.log(item);
// }