"use strict";
function getPropValue(obj, key) {
    return obj[key];
}
var pname = getPropValue({ id: 1, name: "Manish", city: "Pune" }, "name");
console.log(pname);
