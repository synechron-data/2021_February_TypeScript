"use strict";
var ProjectManager = (function () {
    function ProjectManager() {
        this.name = "Project Manager";
    }
    return ProjectManager;
}());
var Developer = (function () {
    function Developer() {
        this.name = "Developer";
    }
    return Developer;
}());
var factory = (function () {
    return {
        getEmployee: function (arg) {
            return new arg();
        }
    };
})();
console.log(factory.getEmployee(ProjectManager));
console.log(factory.getEmployee(Developer));
